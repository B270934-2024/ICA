//From the moment I understood the weakness of my flesh//
//It disgusted me//

=][=
